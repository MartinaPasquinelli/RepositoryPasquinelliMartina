﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Pasquinelli.Martina._4H.Meteo
{
    /// <summary>
    /// Logica di interazione per MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        info[] meteo = new info[13];
        public MainWindow()
        {
            InitializeComponent();

            for (int i = 0; i < meteo.Length; i++)
            {
                meteo[i] = new info();

            }
         
            lettura();
            dgDati.ItemsSource = meteo;
            maxmin();

            //linea di codice per la data giornaliera
            data.Text = Convert.ToString(DateTime.Now.ToString("dddd, dd MMMM yyyy"));
        }

        void scrittura()
        {

            StreamWriter fOut = new StreamWriter("dati.txt");
            for (int i = 0; i < meteo.Length; i++)
            {
                fOut.Write(meteo[i].nome+";");
                fOut.Write(meteo[i].max+";");
                fOut.Write(meteo[i].min+";");
                fOut.WriteLine(meteo[i].esc);
            }                   
            fOut.Close();       
                      
        }

        int lettura()
        {
            int i = 1;
            int conta = 0;

            StreamReader fIn = new StreamReader("dati.txt");


            while (i<meteo.Length && meteo[i].nome != "" )
            {
                string riga = fIn.ReadLine();
                string []letto = riga.Split(';');
                meteo[i].nome = letto[0];
                meteo[i].max = Convert.ToDouble(letto[1]);
                meteo[i].min = Convert.ToDouble(letto[2]);
                meteo[i].esc = Convert.ToDouble(letto[3]);
                conta++;
                i++;
            }
            fIn.Close();
            return conta;
        }

        //funzione per aggiungere le città all'elenco
        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            int idx = 0;
            idx = lettura();
            // Controllo di non aver raggiunto il limite massimo
            if (idx < meteo.Length)
            {

                // Creo la citta
                info nuovo = new info();
                aggiungi finestra = new aggiungi();
                finestra.ShowDialog();

                if (finestra.exit)
                {
                    nuovo.nome = finestra.newname.Text;
                    try
                    {
                        nuovo.max = Convert.ToDouble(finestra.newmax.Text);
                        nuovo.min = Convert.ToDouble(finestra.newmin.Text);
                        // Aggiungo la citta all'array e aggiorno l'indice
                        meteo[idx++] = nuovo;
                        scrittura();
                    }
                    catch
                    {
                        MessageBox.Show("ERRORE");
                    }
                  
 
                }

            }
            else
                MessageBox.Show($"Numero massimo di città inseribili ({meteo.Length}) raggiunto");

            // Collego il mio array al DataGrid 
            maxmin();
    
            dgDati.ItemsSource = meteo;
            dgDati.Items.Refresh();
        }

        //funzione per la ricerca di una città
        private void cerca_Click(object sender, RoutedEventArgs e)
        {
            
            int conta = 0;
            bool aiuto = true;
            info[] item = new info[meteo.Length];
            //inizzializzo item
            for (int i = 0; i < item.Length; i++)
            {
                item[i] = new info();
            }

            //ciclo per cercare ,attraverso il nome , la città desiderata
            for (int i =0; i < meteo.Length;i++)
            {

                if (cercaNome.Text == meteo[i].nome)
                {
                    item[conta] = meteo[i];
                    conta++;
                    aiuto = false;
                }

            }
            /*se "aiuto", la variabile che mi dice se il nome è stato trovato, è false 
              visualizzo i dati contunuti in "item" nella data grid. Se non è stata trovata la città
              la messaggebox comparirà*/
            if (aiuto == false)
            {
                dgDati.ItemsSource = item;
                dgDati.Items.Refresh();
                cercaNome.Text = "";
            }
            else
            {
                MessageBox.Show("Città non presente");
                cercaNome.Text = "";
            }
        }

        //funzione per la ricerca della massima e della minima temparatura 
        void maxmin()
        {
            int i = 0;
            int posmax = i;
            int posmin=i;
            
            //for per la ricerca della temperarura massima e minima
            while (i<meteo.Length && meteo[i].nome !="")
            {
                if (meteo[i].max > meteo[posmax].max)
                {
                    posmax = i;
                }
                if (meteo[i].min < meteo[posmin].min)
                {
                    posmin = i;
                }

                i++;
            }
            lable.Text = $"{meteo[posmax].nome} :{meteo[posmax].max}";
            lable1.Text = $"{meteo[posmin].min} :{meteo[posmin].min}";
        }

        //funzione che al cliccare del bottone fa visualizzare tutte le citta disponibili 
        private void canc_Click(object sender, RoutedEventArgs e)
        {

            dgDati.ItemsSource = meteo;
            dgDati.Items.Refresh();
        }
    }
}
