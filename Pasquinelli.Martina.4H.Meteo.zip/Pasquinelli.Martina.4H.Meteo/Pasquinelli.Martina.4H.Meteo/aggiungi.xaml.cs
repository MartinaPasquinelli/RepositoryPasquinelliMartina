﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Pasquinelli.Martina._4H.Meteo
{
    /// <summary>
    /// Logica di interazione per aggiungi.xaml
    /// </summary>
    public partial class aggiungi : Window
    {
        public bool exit;
        public aggiungi()
        {
            InitializeComponent();
        }

        private void Button_Click_save(object sender, RoutedEventArgs e)
        {
            exit = true;
            this.Close();
        }

        private void Button_Click_exit(object sender, RoutedEventArgs e)
        {
            exit = false;
            this.Close();
        }
    }
}
