﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pasquinelli.Martina._4H.Meteo
{
    class info
    {
        public string nome { get; set; }

        public double max { get; set; }

        public double min { get; set; }

        public double esc { get { return (max - min); } set { } }
    }
}
